questionsArray = [
    {
        question: "Why so JavaScript and Java have similar name?",
        answer: "JavaScript's syntax is loosely based on Java's",
        options: [
            "JavaScript is a stripped-down version of Java",
            "JavaScript's syntax is loosely based on Java's",
            "They both originated on the island of Java",
            "None of the above",
        ]
    },
    {
        question: "__ JavaScript is also called client-side JavaScript.",
        answer: "Navigator",
        options: [
            "Microsoft",
            "Navigator",
            "LiveWire",
            "Native",
        ]
    },
    {
        question: "__ JavaScript is also called server-side JavaScript.",
        answer: "LiveWire",
        options: [
            "Microsoft",
            "Navigator",
            "LiveWire",
            "Native",
        ]
    },
    {
        question: "What are variables used for in JavaScript Programs?",
        answer: "Storing numbers, dates, or other values",
        options: [
            "Storing numbers, dates, or other values",
            "Varying randomly",
            "Causing high-school algebra flashbacks",
            "None of the above",
        ]
    },
    
    
    
    {
        question: "Why so JavaScript and Java have similar name?",
        answer: "JavaScript's syntax is loosely based on Java's",
        options: [
            "JavaScript is a stripped-down version of Java",
            "JavaScript's syntax is loosely based on Java's",
            "They both originated on the island of Java",
            "None of the above",
        ]
    },
]


function showQues(e){
    var ques = document.getElementById("ques");
    ques.innerHTML = "Q" + (e + 1) + ")" +"&nbsp;&nbsp;"  + questionsArray[e].question ;
    var option = document.getElementsByClassName("option");
    for(var i = 0 ; i < option.length ; i++){
        option[i].innerHTML = questionsArray[e].options[i] ;
    }
}
count = 0;
score = 0 ;

function calc(){
    var radios = document.getElementsByClassName("radi");
    var options = document.getElementsByClassName("option")
    for(var i = 0 ; i < radios.length ; i++){
        if(radios[i].checked == true){
            if(options[i].innerHTML == questionsArray[count].answer ){
                score++
            }

        }
    }
}



function nextQues(){
    var radios = document.getElementsByClassName("radi");
    calc()

    if(count < questionsArray.length - 1){
        for(var i = 0 ; i < radios.length ; i++ ){
            if(radios[i].checked == true){
                count++
                showQues(count)
                radios[i].checked = false;
                

            }
        } 
    }
    else{
        alert("You tried well!" + "\n" + "You scored " + score );
    }
   
   
}