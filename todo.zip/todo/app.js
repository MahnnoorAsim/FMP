// connect to firebase
const firebaseConfig = {
  apiKey: "AIzaSyBDOBn_7fcNiLZyBvtlrdFEz9IH2WDfKpA",
  authDomain: "todo-application-477ab.firebaseapp.com",
  databaseURL: "https://todo-application-477ab-default-rtdb.firebaseio.com",
  projectId: "todo-application-477ab",
  storageBucket: "todo-application-477ab.appspot.com",
  messagingSenderId: "585768719044",
  appId: "1:585768719044:web:c05a8b2bfdbd309a0cef91"
};

// write firebase before initialization
const app = firebase.initializeApp(firebaseConfig);

// ----------------------------------------------------------//


var list = document.getElementById("list") ; 

// step2 --> second ye run hoga

// on (add multiple times)

// once (add only one time) | not run properly
 
app.database().ref('todos').on('child_added' , function(data){

  var li = document.createElement("li") ;

  // val() --> predefined function
  // receiving data
  var litext = document.createTextNode(data.val().value);
  // making text li
  li.appendChild(litext);

  var delBtn = document.createElement("button");

  delBtn.setAttribute("class" , "delbtns");
  
  var delText = document.createTextNode("DELETE") ;
  delBtn.setAttribute("id" , data.val().key ) ;
  
  

   delBtn.setAttribute('onclick' , "deleteITem(this)") ;

  delBtn.appendChild(delText) ;

  var editBtn = document.createElement("button"); 
  var editText = document.createTextNode("EDIT") ;
  editBtn.appendChild(editText) ;
  editBtn.setAttribute("id" , data.val().key)
  editBtn.setAttribute("class" , "editbtns")
  editBtn.setAttribute("onclick" , "editItem(this)")

  li.appendChild(delBtn);
  li.appendChild(editBtn) ;

 list.appendChild(li)

 todo_item.value = "" ;
})

// step1 --> pehle ye function execute hoga.


function addtodo(){
    var todo_item = document.getElementById("todo-item") ;

  

    if(todo_item.value !== ""){
      var database = app.database().ref('/todos') ;
      var key = database.push().key
      var todo = {
        value : todo_item.value ,
        key :key
      }
      database.child(key).set(todo)
     todo_item.value = "" ;
    }
    else{
      alert('Fields can not be empty')
    }
  }


  
// target id to remove li
function deleteITem(e){
  app.database().ref("todos").child(e.id).remove()
  e.parentNode.remove()
  
}
// e --> edit button uth kar araha he
// firstChils --> text
// secondChild --> del btn
// thirdChild --> edit btn
function editItem(e){
  var val = e.parentNode.firstChild.nodeValue ;
  var editValue = prompt("Enter Edit Value" , val)
  var editTodo = {
    value : editValue ,
    key : e.id
  }
  app.database().ref("todos").child(e.id).set(editTodo)

  e.parentNode.firstChild.nodeValue = editValue ;

}




function deleteAll(){
  app.database().ref("todos").remove()
  list.innerHTML = '' ;
}